/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/(community)` | `/(community)/addPost` | `/(community)/allPosts` | `/(community)/managePosts` | `/(encyclopedia)` | `/(encyclopedia)/plantEncyclopedia` | `/(journal)` | `/(journal)/AddJournal` | `/(journal)/JournalDetail` | `/(journal)/ManageJournal` | `/(journal)/UpdateJournal` | `/(journal)/ViewJournal` | `/(login)` | `/(login)/login` | `/(login)/signup` | `/(product)` | `/(product)/CartScreen` | `/(product)/MyOrders` | `/(product)/OrderDetail` | `/(product)/ShippingDetails` | `/(product)/productDetail` | `/(sales)` | `/(sales)/SaleCategory` | `/(sales)/SalesId` | `/(sales)/addProduct` | `/(sales)/manageProduct` | `/(splash)` | `/(splash)/firstScreen` | `/(splash)/secondScreen` | `/(splash)/thirdScreen` | `/(tabs)` | `/(tabs)/Community` | `/(tabs)/Home` | `/(tabs)/Journal` | `/(tabs)/Sales` | `/(tabs)/profile` | `/AddJournal` | `/CartScreen` | `/Community` | `/Home` | `/Journal` | `/JournalDetail` | `/ManageJournal` | `/MyOrders` | `/OrderDetail` | `/SaleCategory` | `/Sales` | `/SalesId` | `/ShippingDetails` | `/UpdateJournal` | `/ViewJournal` | `/_sitemap` | `/addPost` | `/addProduct` | `/allPosts` | `/firstScreen` | `/login` | `/managePosts` | `/manageProduct` | `/plantEncyclopedia` | `/productDetail` | `/profile` | `/secondScreen` | `/signup` | `/thirdScreen`;
      DynamicRoutes: `/${Router.SingleRoutePart<T>}` | `/(community)/${Router.SingleRoutePart<T>}` | `/(encyclopedia)/${Router.SingleRoutePart<T>}` | `/(sales)/${Router.SingleRoutePart<T>}`;
      DynamicRouteTemplate: `/(community)/[post]` | `/(encyclopedia)/[id]` | `/(sales)/[product]` | `/[id]` | `/[post]` | `/[product]`;
    }
  }
}
